package com.leadicon.assignment.leadicon_backend_assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeadiconBackendAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
